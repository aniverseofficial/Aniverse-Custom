# Aniverse Deployment Test Report

Generated: 2026-09-23T08:51:55.589Z
Base URL: http://localhost:4000
External integrations: skipped

## Final deployment gate: **FAIL**
**Overall rating: 0.0/10 (0/100)**
PASS: 0 · WARN: 0 · FAIL: 1 · SKIP: 0

| Category | Rating | Pass | Warn | Fail | Skip |
|---|---:|---:|---:|---:|---:|
| Availability | 0.0/10 | 0 | 0 | 1 | 0 |

## Detailed results
### Availability
- **FAIL** — Server reachable — Could not reach http://localhost:4000

## Interpretation
Deployment should not proceed until failed critical checks are fixed and the suite is rerun.

> Note: Automated API tests cannot prove real Razorpay settlement, courier pickup, physical delivery, DNS, TLS, or human visual quality unless the corresponding external/browser tests are enabled and credentials are valid.